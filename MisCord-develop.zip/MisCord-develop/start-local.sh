#!/bin/bash

pm2-runtime --output logs/out.log --error logs/error.log start yarn run start